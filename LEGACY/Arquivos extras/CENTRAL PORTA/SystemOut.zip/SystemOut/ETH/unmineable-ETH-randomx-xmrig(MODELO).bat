xmrig.exe -a rx -o stratum+ssl://rx.unmineable.com:443 -u ETH:0xc21E95Ce2402dA8299a0Eb9e150faB487D85FcDD.Pedro-ba008 -p x 
pause